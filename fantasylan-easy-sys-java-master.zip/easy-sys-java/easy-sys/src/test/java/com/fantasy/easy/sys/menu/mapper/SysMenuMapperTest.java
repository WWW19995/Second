package com.fantasy.easy.sys.menu.mapper;

/**
 * 测试类，当前没有测试
 * 
 * */
//@SpringBootTest(classes=EasyApplicationException.class)
//public class SysMenuMapperTest extends AbstractTestNGSpringContextTests {
//
//  @Test
//  public void queryListParentId() {
//  }
//
//  @Test
//  public void queryNotButtonList() {
//  }
//
//  @Test
//  public void selectList() {
//  }
//}
