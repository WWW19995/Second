package com.fantasy.easy.sys.user;

/**
 * Created by fantasy on 2020/7/27.
 */
public class SysUserLoginVO {
    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
