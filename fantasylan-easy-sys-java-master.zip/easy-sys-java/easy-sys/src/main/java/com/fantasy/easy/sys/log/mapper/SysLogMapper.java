package com.fantasy.easy.sys.log.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fantasy.easy.sys.log.SysLogEntity;

/**
 * @author fantasy
 */
public interface SysLogMapper extends  BaseMapper<SysLogEntity> {

	
}
