/**
 * fantasy
 */
package com.fantasy.easy.sys.i18n.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fantasy.easy.core.entity.SysI18nEntity;

/**
 * @author fantasy
 *2020年2月9日 下午2:55:57
 */
public interface SysI18nMapper extends  BaseMapper<SysI18nEntity> {

	
}
