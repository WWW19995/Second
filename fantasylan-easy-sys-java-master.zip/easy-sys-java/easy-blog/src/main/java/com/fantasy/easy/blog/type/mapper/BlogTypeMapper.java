package com.fantasy.easy.blog.type.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fantasy.easy.blog.type.BlogTypeEntity;

@Mapper
public interface BlogTypeMapper extends BaseMapper<BlogTypeEntity> {

}