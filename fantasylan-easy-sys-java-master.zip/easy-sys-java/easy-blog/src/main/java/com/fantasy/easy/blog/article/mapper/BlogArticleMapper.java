package com.fantasy.easy.blog.article.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fantasy.easy.blog.article.BlogArticleEntity;

@Mapper
public interface BlogArticleMapper extends BaseMapper<BlogArticleEntity> {

}