package com.fantasy.easy.core.entity;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("sys_user")
public class SysUserEntity extends BaseEntity {

	@TableId(type= IdType.AUTO)
	private Long userId;

	@NotBlank(message="用户名不能为空")
	private String userName;

	private String userPwd;

	private String userSalt;

	@Email(message="邮箱格式不正确")
	private String userEmail;

	private String userMobile;

	@Min(value=0,message="状态不能小于0")
	@Max(value=1, message="状态不能大于1")
	private Integer userStatus;

	@TableField(exist = false)
	private String introduction;

	@TableField(exist = false)
	private String avatar;

	@TableField(exist = false)
	private String name;

	@TableField(exist = false)
	private List<Long> roleIdList;

	@TableField(exist = false)
	private List<SysMenuEntity> menuList;

	@TableField(exist = false)
	private List<String> permissions;

	@TableField(exist = false)
	private List<String> roles;

	public List<String> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<String> auths) {
		this.permissions = auths;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getUserId() {
		return userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserSalt() {
		return userSalt;
	}

	public void setUserSalt(String userSalt) {
		this.userSalt = userSalt;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public Integer getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}

	public List<Long> getRoleIdList() {
		return roleIdList;
	}

	public void setRoleIdList(List<Long> roleIdList) {
		this.roleIdList = roleIdList;
	}

	/**
	 * @return the roles
	 */
	public List<String> getRoles() {
		return roles;
	}

	/**
	 * @param roles
	 *            the roles to set
	 */
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	/**
	 * @return the introduction
	 */
	public String getIntroduction() {
		return introduction;
	}

	/**
	 * @param introduction
	 *            the introduction to set
	 */
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}

	/**
	 * @return the avatar
	 */
	public String getAvatar() {
		return avatar;
	}

	/**
	 * @param avatar
	 *            the avatar to set
	 */
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	/**
	 * @return the auth
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the auth to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the menuList
	 */
	public List<SysMenuEntity> getMenuList() {
		return menuList;
	}

	/**
	 * @param menuList
	 *            the menuList to set
	 */
	public void setMenuList(List<SysMenuEntity> menuList) {
		this.menuList = menuList;
	}

}