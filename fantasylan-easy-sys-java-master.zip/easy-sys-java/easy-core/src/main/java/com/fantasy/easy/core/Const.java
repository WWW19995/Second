/**
 * fantasy
 */
package com.fantasy.easy.core;

/**
 * @author fantasy
 *2020年2月9日 下午3:41:55
 */
public class Const {

	public static final String LANG_CN = "zh-CN";
	public static final String LANG_EN = "en-US";

	public static final String USER_INFO_SESSION = "userInfoSession";
	
}
